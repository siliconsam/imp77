
This is the current working IMP-77 80386 compiler and library source.
Use the "create directories" option in your unzipper, and it will put the various sources into subdirectories.

To use this compiler (on Windows) you need the Microsoft 32-bit linker and associated libraries.
(I used the Community edition of Visual Studio 2019 on Windows 10)

To use the compiler:-
1) open up an x86 developer prompt shell (provided by Visual Studio 2019).
2) cd to where you unzipped the imp32.zip
3) run setenv
   this sets up the appropriate %PATH% to use the compiler
   It also creates 2 logicals
   IMP_INSTALL_HOME pointing to the imp32 installation home
   IMP_SOURCE_HOME pointing to the source directories
        default location is %IMP_INSTALL_HOME%\source
        You could move the source directory to another location
        but don't forget to amend setenv.cmd
   
4) To compile (and optionally link) an IMP program
   run the batch script with parameter
   e.g. imp32 <file>
   Do NOT include the .imp extension, the script "ass-u-me"s that extension.
   Examine the imp32 script to see the available command-line options

5) To run the generated imp executable <exe>.exe type <exe> (where <exe> == <file>
   If the imp program expects input and or output files then use the following format
   <exe> <in1>,<in2>... /<out1>,<out2>..
   A maximumum of 4 input files and 4 output files is currently implemented
   If the input/output file has binary data i.e. not a text file then use the notation
   <infile>:b     or <outfile>:b
   
   Refer to imp32.bat to see this used when running i32p1 and i32p2

6) CAVEAT: The imp32.bat script will only link one object file
   If you want to create a program which links multiple object files use the imp32multi script
   This calls imp32 multiple times, compiling each IMP source file given as a parameter
   The first file parameter is assumed to be the top program with source
   %begin
      <code>
   %end
   %endoffile

   All other files should be coded in a similar style to the library source files

   If there is a non-IMP file to be linked in then
   a) Use imp32 for each IMP source file
   b) Generate a COFF file for each of the non-IMP source files.
   c) Use imp32multilink in a similar fashion to imp32multi.
   **** The first file listed MUST be a COFF file generated from an IMP "program" source file.
   
N.B. pass1.imp, pass2imp are the source files for i32p1.exe, i32p2.exe respectively
     i32p3 is generated from C code in the source\coff folder (this uses the Visual Studio C compiler)

To build the IMP77 compiler programs examine the %IMP_SOURCE_HOME%\build.bat script
To "release" the new compiler version examine the %IMP_SOURCE_HOME%\release.bat script

JD McMullin

This release is equivalent to release 1.03 (2003) created by Andy Davis
I have just created build, release scripts and added some documentation and examples.