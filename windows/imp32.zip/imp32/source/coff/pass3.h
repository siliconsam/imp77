void readifrecord(FILE *infile, int &type, int &length, unsigned char *buffer);
void writeobjectrecord(FILE *outfile, int type, int count, unsigned char * data);

// Intermediate file types:
#define IF_OBJ		0	// plain object code
#define IF_DATA		1	// dataseg offset code word
#define IF_CONST	2	// const seg offset code word
#define IF_DISPLAY	3	// display seg offset code word
#define IF_JUMP		4	// unconditional jump to label
#define IF_JCOND	5	// cond jump to label JE, JNE, JG, JGE, JL, JLE, JA, JAE, JB, JBE
#define IF_CALL		6	// call a label
#define IF_LABEL	7	// define a label
#define IF_FIXUP	8	// define location for stack fixup instruction
#define IF_SETFIX	9	// stack fixup <location> <amount>
#define IF_REQEXT	10	// external name spec
#define IF_REFEXT	12	// external name relative offset code word
#define	IF_BSS		13	// BSS segment offset code word
#define IF_COTWORD	14	// Constant table word
#define IF_DATWORD	15	// Data segment word
#define IF_SWTWORD	16	// switch table entry - actually a label ID
#define	IF_SOURCE	17	// name of the source file
#define IF_DEFEXTCODE	18	// define a code label that is external
#define IF_DEFEXTDATA	19	// define a data label that is external
#define IF_SWT		20	// switch table offset code word
#define IF_LINE		21	// line number info for debugger

#define JE 24
#define JNE 25
#define JG 26
#define JGE 27
#define JL 28
#define JLE 29

#define WORDSIZE	4

// Interface to COFF file writer
void setsize(int section, int s);
void setfile(FILE * out, int offset);
void writebyte(int section, unsigned char b);
void writew16(int section, int w);
void writew32(int section, int w);

void flushout();

// definitions of COFF structures.  Some systems may define these
// for you, but for portability they are provided here...
// Note however that we also define some structure sizes, because the
// lame MS compiler can mess you up when you do "sizeof"

#define SYMNMLEN	8
#define FILNMLEN	14
#define	DIMNUM		4

struct cofffilehdr
{
	unsigned short	f_magic;	// magic number
	unsigned short	f_nscns;	// number of sections
	long			f_timdat;	// time and date stamp
	long			f_symptr;	// file pointer to symbol table
	long			f_nsyms;	// number of symbol table entries
	unsigned short	f_opthdr;	// size of (opt hdr)
	unsigned short	f_flags;	// flags
};

#define SZFILEHDR	(sizeof(struct cofffilehdr))

struct coffscnhdr
{
	char			s_name[SYMNMLEN];	// section name
	long			s_paddr;			// physical address
	long			s_vaddr;			// virtual address
	long			s_size;				// section size
	long			s_scnptr;			// file ptr to raw data
	long			s_relptr;			// file pointer to relocation list
	long			s_lnnoptr;			// file point to line numbers
	unsigned short	s_nreloc;			// number of relocations
	unsigned short	s_nlnno;			// number of line numbers
	long			s_flags;			// section flags
};

#define SZSECHDR	(sizeof(struct coffscnhdr))

struct coffreloc
{
	long			r_vaddr;		// (virtual) address of reference
	long			r_symndx;		// index into symbol table
	unsigned short	r_type;			// relocation type
};

#define SZRELOC		10

struct cofflineno
{
	union
	{
		long	l_symndx;
		long	l_paddr;
	}	l_addr;
	unsigned short l_lnno;
};

#define	SZLINENO	6

struct coffsyment
{
	union
	{
		char	n_name[SYMNMLEN];		// the actual name (if <= 8 chars)
		struct
		{
			long	n_zeroes;			// == 0L if the name is in the string table
			long	n_offset;			// the string table pointer
		} n_n;
	} n;
	long			n_value;			// value of the symbol
	short			n_scnum;			// section number
	unsigned short	n_type;				// type and derived type
	char			n_sclass;			// storage class
	char			n_numaux;			// number of auxilliary entries
};

#define SZSYMENT	18

struct coffauxscn
{
	long			x_scnlen;	// section length
	unsigned short	x_nreloc;	// number of relocations
	unsigned short	x_nlnno;	// number of line numbers
	long			x_chsum;	// COMDAT checksum
	unsigned short	x_secno;	// COMDAT section number
	unsigned short	x_selno;	// COMDAT selection number
	unsigned short	x_pad;		// not used
};




