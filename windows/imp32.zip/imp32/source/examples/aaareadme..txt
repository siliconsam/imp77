Useful tips
1) ALWAYS have a blank line as the last line in an IMP source file

2) Data external to an IMP module is NOT properly implemented by the imp32 compiler version
   That is, imp32p2 (pass2) and imp32p3 (pass3) programs need to be amended

   This is indicated when the imp32 script reports "unexpected tag". This is reported by the pass3 program
   Unfortunately, no indication of which .ibj record line is in error.
   
   Current workaround is to "tweak" the generated .ibj file which contains references to external data
   The ABSEXT records in the .ibj file will be faulty
   
   Use ibj2assemble %1.ibj %1.assemble to examine a human-readable .ibj file (.assemble)
   
   Edit the faulty ABSEXT records (faulty if "" string present) to refer to the proper external symbol
   The LINE ibj record prior to the ABSEXT record can be useful when referring to the IMP source to
   find the missing exterrnal reference
   
   Once the faulty ABSEXT records are corrected in the .assemble file then use
   
   assemble2ibj %1.assemble %1.ibj
   
   As pass3 does not correctly interpret ABSEXT ibj records you need to use the supplied utility ibj2coff
   to generate valid .obj files from the .ibj files where the .ibj file contains external data references
   or external data definitions.
   
   ibj2coff %1.ibj %1.obj

3) The pass2 program also generates an incorrect .ibj  SOURCE record which should indicate the corresponding
   IMP source file. The source is always given as "TEST.IMP"

4) The pass2 compiler needs to be amended to accept the NIL pointer semantics
   See example2.txt for an appropriate fix.

5) If running an IMP file which uses file I/O then the command line has the following format
   
    %1 infile1,infile2/outfile1,outfile2
    There are a maximum of 4 input files allowed and 4 output files. The / separates the input files from
    the output files. See runimp.c in the lib folder
    
    If a file (input or output) is a binary file then append :b to the file name

    Examples are:
    
    imp32p1 %1.imp,%IMP_PERMS_HOME%stdperm.imp/%1.icd:b,%1.lst
    
    imp32p2 %1.icd:b,%1.imp/%1.ibj,%1.cod
    
    imp32p3 is a C program and uses the usual program parameter layout.
    
    imp32p3 %1.ibj %1.obj
    
6) If a program is split into a number of IMP source files then compile each IMP source file with the -c option
   (this causes the link stage to be omitted)
   
   The collection of .obj files can the be linked by the command
   
   imp32multilink %1 %2 ... %n
   
   where %1 is the main module (%begin .. %end) and the %2 .. %n are the IMP sub-modules
   Each %i parameter omits the .obj file extension
   
   Example:
   
   imp32multilink test140 test140sub

7) This version of an IMP77 compiler does not implement embedded machine code
